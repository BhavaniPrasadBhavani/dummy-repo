import { ResultCard } from "../ResultCard";

export default function ResultCardExample() {
  return (
    <div className="max-w-2xl mx-auto p-4">
      <ResultCard
        crop="rice"
        confidence={0.905}
        alternatives={[
          { crop: "wheat", confidence: 0.06 },
          { crop: "maize", confidence: 0.035 },
        ]}
        onSave={() => console.log("Save clicked")}
        onNewPrediction={() => console.log("New prediction clicked")}
      />
    </div>
  );
}
