import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import type { Prediction } from "@shared/schema";

interface HistoryCardProps {
  prediction: Prediction;
  onDelete?: (id: string) => void;
}

export function HistoryCard({ prediction, onDelete }: HistoryCardProps) {
  const date = new Date(prediction.createdAt);
  const formattedDate = date.toLocaleDateString("en-US", {
    month: "short",
    day: "numeric",
    year: "numeric",
  });

  return (
    <Card className="hover-elevate" data-testid={`card-history-${prediction.id}`}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between gap-4">
          <div className="flex-1 space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="text-lg font-semibold capitalize" data-testid="text-crop">
                {prediction.recommendedCrop}
              </h3>
              <Badge variant="secondary">
                {(prediction.confidence * 100).toFixed(1)}%
              </Badge>
            </div>

            <div className="grid grid-cols-2 gap-2 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">N:</span>
                <span className="font-mono">{prediction.nitrogen}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">P:</span>
                <span className="font-mono">{prediction.phosphorus}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">K:</span>
                <span className="font-mono">{prediction.potassium}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Temp:</span>
                <span className="font-mono">{prediction.temperature}°C</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Humidity:</span>
                <span className="font-mono">{prediction.humidity}%</span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">pH:</span>
                <span className="font-mono">{prediction.ph}</span>
              </div>
              <div className="flex justify-between col-span-2">
                <span className="text-muted-foreground">Rainfall:</span>
                <span className="font-mono">{prediction.rainfall} mm</span>
              </div>
            </div>

            <div className="flex items-center justify-between pt-2 border-t">
              <span className="text-xs text-muted-foreground" data-testid="text-date">
                {formattedDate}
              </span>
              {onDelete && (
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => onDelete(prediction.id)}
                  data-testid="button-delete"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
