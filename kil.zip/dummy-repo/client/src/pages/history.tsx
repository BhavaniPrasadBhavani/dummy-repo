import { useQuery, useMutation } from "@tanstack/react-query";
import { useLocation } from "wouter";
import { HistoryCard } from "@/components/HistoryCard";
import { EmptyHistory } from "@/components/EmptyHistory";
import { useToast } from "@/hooks/use-toast";
import { apiRequest, queryClient } from "@/lib/queryClient";
import type { Prediction } from "@shared/schema";

export default function History() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();

  const { data: predictions = [], isLoading } = useQuery<Prediction[]>({
    queryKey: ["/api/predictions"],
  });

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const response = await apiRequest("DELETE", `/api/predictions/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/predictions"] });
      toast({
        title: "Deleted",
        description: "Prediction removed from history",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to delete prediction",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (id: string) => {
    deleteMutation.mutate(id);
  };

  if (isLoading) {
    return (
      <div className="min-h-screen py-8 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary mx-auto mb-4"></div>
          <p className="text-muted-foreground">Loading history...</p>
        </div>
      </div>
    );
  }

  if (predictions.length === 0) {
    return (
      <div className="min-h-screen py-8">
        <EmptyHistory onGetStarted={() => setLocation("/predict")} />
      </div>
    );
  }

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-4xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Prediction History</h1>
          <p className="text-muted-foreground">
            View and manage your previous crop recommendations
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {predictions.map((prediction) => (
            <HistoryCard
              key={prediction.id}
              prediction={prediction}
              onDelete={handleDelete}
            />
          ))}
        </div>
      </div>
    </div>
  );
}
