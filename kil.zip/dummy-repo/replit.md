# CropAI Advisor

## Overview
CropAI Advisor is a web application that provides AI-powered crop recommendations based on soil and environmental parameters. Farmers can input data about nitrogen, phosphorus, potassium levels, temperature, humidity, pH, and rainfall to receive intelligent suggestions on which crops to grow.

## Current State
The application is successfully set up and running in the Replit environment. The frontend is accessible through the webview, and the backend API is operational on port 5000.

### Setup Status
- ✅ Node.js 20 installed with all dependencies
- ✅ Vite dev server configured for Replit proxy (port 5000, host 0.0.0.0, allowedHosts: true)
- ✅ Workflow configured and running (dev-server)
- ✅ PostgreSQL database available and schema migrated
- ✅ Deployment configuration set up (autoscale)
- ✅ OPENROUTER_API_KEY configured (AI predictions ready)
- ✅ Firebase authentication fully configured and working

### How to Use
1. **Register**: Go to `/register` to create a new account with email and password
2. **Login**: Go to `/login` to sign in with your credentials
3. **Get Predictions**: Navigate to `/predict` to input soil parameters and get AI crop recommendations
4. **View History**: Check `/history` to see your past predictions

## Recent Changes (November 16, 2025)
- ✅ Imported GitHub project from zip archive and extracted to root
- ✅ Installed Node.js 20 and all npm dependencies
- ✅ Configured Vite server for Replit environment (0.0.0.0:5000, allowedHosts: true, HMR clientPort 443)
- ✅ Set up dev-server workflow with webview output on port 5000
- ✅ Configured PostgreSQL database and ran migrations (npm run db:push)
- ✅ Configured deployment settings (autoscale with npm build and start)
- ✅ Application is running successfully and accessible through webview
- ✅ OPENROUTER_API_KEY already configured - AI predictions ready to use
- ℹ️ Firebase authentication is optional and gracefully disabled when not configured

## Project Architecture

### Technology Stack
- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Express.js + Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Firebase Email/Password Authentication
- **AI Service**: OpenRouter API (using Meta Llama 3.3 70B Instruct model)
- **UI Components**: Radix UI + Tailwind CSS + Framer Motion

### Project Structure
```
├── client/               # Frontend React application
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── pages/       # Page components (home, predict, history)
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utilities and query client
│   └── index.html
├── server/              # Backend Express server
│   ├── index.ts         # Main server entry point
│   ├── routes.ts        # API route handlers
│   ├── storage.ts       # Database operations
│   └── vite.ts          # Vite dev server integration
├── shared/              # Shared types and schemas
│   └── schema.ts        # Database schema and validation
└── attached_assets/     # Static assets (crop images)
```

### Key Features
1. **User Authentication**: Firebase email/password login with location field
2. **Prediction Form**: Input soil and environmental parameters
3. **AI Recommendations**: Get crop suggestions with confidence scores
4. **Prediction History**: View and manage past predictions (requires database)
5. **Responsive UI**: Works on desktop and mobile devices
6. **Dark/Light Theme**: User preference toggle

### API Endpoints
- `POST /api/predict` - Generate crop recommendation
- `GET /api/predictions` - Retrieve prediction history
- `DELETE /api/predictions/:id` - Delete a prediction

### Database Schema
The `predictions` table stores:
- Soil parameters (nitrogen, phosphorus, potassium, pH)
- Environmental data (temperature, humidity, rainfall)
- AI predictions (recommended crop, confidence, alternatives)
- Timestamp (createdAt)

### Available Crop Types
rice, wheat, maize, chickpea, kidneybeans, pigeonpeas, mothbeans, mungbean, blackgram, lentil, pomegranate, banana, mango, grapes, watermelon, muskmelon, apple, orange, papaya, coconut, cotton, jute, coffee

## Environment Variables
- `OPENROUTER_API_KEY` - ✅ Configured - API key for OpenRouter AI service
- `DATABASE_URL` - ✅ Configured - PostgreSQL connection string
- `PORT` - Server port (defaults to 5000)
- `NODE_ENV` - Environment mode (development/production)
- `VITE_FIREBASE_API_KEY` - (Optional) Firebase API key for authentication
- `VITE_FIREBASE_AUTH_DOMAIN` - (Optional) Firebase auth domain
- `VITE_FIREBASE_PROJECT_ID` - (Optional) Firebase project ID
- `VITE_FIREBASE_STORAGE_BUCKET` - (Optional) Firebase storage bucket
- `VITE_FIREBASE_MESSAGING_SENDER_ID` - (Optional) Firebase messaging sender ID
- `VITE_FIREBASE_APP_ID` - (Optional) Firebase app ID

## Development Commands
- `npm run dev` - Start development server with Vite HMR
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run check` - Run TypeScript type checking
- `npm run db:push` - Push database schema changes

## User Preferences
No specific user preferences recorded yet.

## Notes
- The application uses port 5000 exclusively (both frontend and backend)
- Vite is configured to allow all hosts for Replit's proxy environment
- The server uses SO_REUSEPORT for better performance
- AI model responses are parsed from JSON format with fallback error handling
