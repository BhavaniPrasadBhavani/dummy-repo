import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { cropInputSchema, insertPredictionSchema } from "@shared/schema";
import { fromZodError } from "zod-validation-error";

const OPENROUTER_API_KEY = process.env.OPENROUTER_API_KEY;

export async function registerRoutes(app: Express): Promise<Server> {
  app.post("/api/predict", async (req, res) => {
    try {
      const validationResult = cropInputSchema.safeParse(req.body);
      
      if (!validationResult.success) {
        const validationError = fromZodError(validationResult.error);
        return res.status(400).json({ 
          error: "Invalid input parameters",
          details: validationError.message 
        });
      }

      const input = validationResult.data;

      if (!OPENROUTER_API_KEY) {
        return res.status(500).json({ 
          error: "API key not configured. Please set OPENROUTER_API_KEY." 
        });
      }

      const prompt = `You are an agricultural AI expert specialized in crop recommendations. Based on the following soil and environmental parameters, recommend the most suitable crop to grow.

Parameters:
- Nitrogen (N): ${input.nitrogen}
- Phosphorus (P): ${input.phosphorus}
- Potassium (K): ${input.potassium}
- Temperature: ${input.temperature}°C
- Humidity: ${input.humidity}%
- Soil pH: ${input.ph}
- Rainfall: ${input.rainfall}mm

Available crops to choose from: rice, wheat, maize, chickpea, kidneybeans, pigeonpeas, mothbeans, mungbean, blackgram, lentil, pomegranate, banana, mango, grapes, watermelon, muskmelon, apple, orange, papaya, coconut, cotton, jute, coffee.

Respond ONLY with a valid JSON object in this exact format (no markdown, no extra text):
{
  "recommendedCrop": "crop_name",
  "confidence": 0.95,
  "alternatives": [
    {"crop": "alternative1", "confidence": 0.75},
    {"crop": "alternative2", "confidence": 0.60},
    {"crop": "alternative3", "confidence": 0.45}
  ],
  "reasoning": "Brief explanation of why this crop is recommended"
}

The confidence should be a decimal between 0 and 1. Choose the crop that best matches these specific environmental conditions.`;

      const response = await fetch("https://openrouter.ai/api/v1/chat/completions", {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${OPENROUTER_API_KEY}`,
          "Content-Type": "application/json",
          "HTTP-Referer": "https://cropaiadvisor.replit.app",
          "X-Title": "CropAI Advisor"
        },
        body: JSON.stringify({
          model: "meta-llama/llama-3.3-70b-instruct:free",
          messages: [
            {
              role: "user",
              content: prompt
            }
          ],
          temperature: 0.3,
          max_tokens: 500
        })
      });

      if (!response.ok) {
        const errorText = await response.text();
        console.error("OpenRouter API error:", errorText);
        return res.status(response.status).json({ 
          error: "Failed to get prediction from AI model",
          details: errorText
        });
      }

      const data = await response.json();
      const aiResponse = data.choices[0]?.message?.content;

      if (!aiResponse) {
        return res.status(500).json({ 
          error: "No response from AI model" 
        });
      }

      let prediction;
      try {
        const jsonMatch = aiResponse.match(/\{[\s\S]*\}/);
        const jsonStr = jsonMatch ? jsonMatch[0] : aiResponse;
        prediction = JSON.parse(jsonStr);
      } catch (parseError) {
        console.error("Failed to parse AI response:", aiResponse);
        return res.status(500).json({ 
          error: "Failed to parse AI response",
          rawResponse: aiResponse
        });
      }

      const predictionData = {
        ...input,
        recommendedCrop: prediction.recommendedCrop.toLowerCase(),
        confidence: prediction.confidence,
        alternativeCrops: prediction.alternatives?.map((alt: any) => alt.crop.toLowerCase()) || []
      };

      const savedPrediction = await storage.createPrediction(predictionData);

      res.json({
        ...prediction,
        id: savedPrediction.id
      });

    } catch (error) {
      console.error("Prediction error:", error);
      res.status(500).json({ 
        error: "Internal server error",
        message: error instanceof Error ? error.message : "Unknown error"
      });
    }
  });

  app.get("/api/predictions", async (req, res) => {
    try {
      const predictions = await storage.getAllPredictions();
      res.json(predictions);
    } catch (error) {
      console.error("Error fetching predictions:", error);
      res.status(500).json({ 
        error: "Failed to fetch predictions" 
      });
    }
  });

  app.delete("/api/predictions/:id", async (req, res) => {
    try {
      const { id } = req.params;
      await storage.deletePrediction(id);
      res.json({ success: true });
    } catch (error) {
      console.error("Error deleting prediction:", error);
      res.status(500).json({ 
        error: "Failed to delete prediction" 
      });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
