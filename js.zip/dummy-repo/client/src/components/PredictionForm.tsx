import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { cropInputSchema, type CropInput } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Slider } from "@/components/ui/slider";
import { Beaker, Cloud, Droplets, Loader2 } from "lucide-react";

interface PredictionFormProps {
  onSubmit: (data: CropInput) => void;
  isLoading?: boolean;
}

export function PredictionForm({ onSubmit, isLoading = false }: PredictionFormProps) {
  const form = useForm<CropInput>({
    resolver: zodResolver(cropInputSchema),
    defaultValues: {
      nitrogen: 50,
      phosphorus: 50,
      potassium: 50,
      temperature: 25,
      humidity: 70,
      ph: 6.5,
      rainfall: 100,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Beaker className="h-5 w-5 text-primary" />
              <CardTitle>Soil Nutrients</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="nitrogen"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between">
                    <FormLabel>Nitrogen (N)</FormLabel>
                    <span className="text-sm font-mono text-muted-foreground">{field.value}</span>
                  </div>
                  <FormControl>
                    <Slider
                      min={0}
                      max={140}
                      step={1}
                      value={[field.value]}
                      onValueChange={([value]) => field.onChange(value)}
                      data-testid="slider-nitrogen"
                    />
                  </FormControl>
                  <FormDescription>Range: 0-140</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="phosphorus"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between">
                    <FormLabel>Phosphorus (P)</FormLabel>
                    <span className="text-sm font-mono text-muted-foreground">{field.value}</span>
                  </div>
                  <FormControl>
                    <Slider
                      min={0}
                      max={140}
                      step={1}
                      value={[field.value]}
                      onValueChange={([value]) => field.onChange(value)}
                      data-testid="slider-phosphorus"
                    />
                  </FormControl>
                  <FormDescription>Range: 0-140</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="potassium"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between">
                    <FormLabel>Potassium (K)</FormLabel>
                    <span className="text-sm font-mono text-muted-foreground">{field.value}</span>
                  </div>
                  <FormControl>
                    <Slider
                      min={0}
                      max={140}
                      step={1}
                      value={[field.value]}
                      onValueChange={([value]) => field.onChange(value)}
                      data-testid="slider-potassium"
                    />
                  </FormControl>
                  <FormDescription>Range: 0-140</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Cloud className="h-5 w-5 text-primary" />
              <CardTitle>Climate Conditions</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="temperature"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between">
                    <FormLabel>Temperature</FormLabel>
                    <span className="text-sm font-mono text-muted-foreground">{field.value}°C</span>
                  </div>
                  <FormControl>
                    <Slider
                      min={0}
                      max={50}
                      step={0.1}
                      value={[field.value]}
                      onValueChange={([value]) => field.onChange(value)}
                      data-testid="slider-temperature"
                    />
                  </FormControl>
                  <FormDescription>Range: 0-50°C</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="humidity"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between">
                    <FormLabel>Humidity</FormLabel>
                    <span className="text-sm font-mono text-muted-foreground">{field.value}%</span>
                  </div>
                  <FormControl>
                    <Slider
                      min={0}
                      max={100}
                      step={1}
                      value={[field.value]}
                      onValueChange={([value]) => field.onChange(value)}
                      data-testid="slider-humidity"
                    />
                  </FormControl>
                  <FormDescription>Range: 0-100%</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <div className="flex items-center gap-2">
              <Droplets className="h-5 w-5 text-primary" />
              <CardTitle>Soil Properties</CardTitle>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <FormField
              control={form.control}
              name="ph"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between">
                    <FormLabel>Soil pH</FormLabel>
                    <span className="text-sm font-mono text-muted-foreground">{field.value}</span>
                  </div>
                  <FormControl>
                    <Slider
                      min={3}
                      max={10}
                      step={0.1}
                      value={[field.value]}
                      onValueChange={([value]) => field.onChange(value)}
                      data-testid="slider-ph"
                    />
                  </FormControl>
                  <FormDescription>Range: 3-10</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />

            <FormField
              control={form.control}
              name="rainfall"
              render={({ field }) => (
                <FormItem>
                  <div className="flex items-center justify-between">
                    <FormLabel>Rainfall</FormLabel>
                    <span className="text-sm font-mono text-muted-foreground">{field.value} mm</span>
                  </div>
                  <FormControl>
                    <Slider
                      min={0}
                      max={300}
                      step={1}
                      value={[field.value]}
                      onValueChange={([value]) => field.onChange(value)}
                      data-testid="slider-rainfall"
                    />
                  </FormControl>
                  <FormDescription>Range: 0-300 mm</FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
          </CardContent>
        </Card>

        <Button
          type="submit"
          size="lg"
          className="w-full"
          disabled={isLoading}
          data-testid="button-predict"
        >
          {isLoading ? (
            <>
              <Loader2 className="mr-2 h-5 w-5 animate-spin" />
              Analyzing Soil Parameters...
            </>
          ) : (
            "Get Crop Recommendation"
          )}
        </Button>
      </form>
    </Form>
  );
}
