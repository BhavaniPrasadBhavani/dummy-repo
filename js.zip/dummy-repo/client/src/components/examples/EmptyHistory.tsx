import { EmptyHistory } from "../EmptyHistory";

export default function EmptyHistoryExample() {
  return (
    <EmptyHistory onGetStarted={() => console.log("Get started clicked")} />
  );
}
