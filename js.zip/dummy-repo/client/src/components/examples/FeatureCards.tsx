import { FeatureCards } from "../FeatureCards";

export default function FeatureCardsExample() {
  return <FeatureCards />;
}
