# CropAI Advisor

## Overview
CropAI Advisor is a web application that provides AI-powered crop recommendations based on soil and environmental parameters. Farmers can input data about nitrogen, phosphorus, potassium levels, temperature, humidity, pH, and rainfall to receive intelligent suggestions on which crops to grow.

## Current State
The application is successfully set up and running in the Replit environment. The frontend is accessible through the webview, and the backend API is operational on port 5000.

### Setup Status
- ✅ Node.js and dependencies installed
- ✅ Vite dev server configured for Replit proxy (port 5000, host 0.0.0.0)
- ✅ Workflow configured and running
- ✅ OpenRouter API key configured for AI predictions
- ✅ Deployment configuration set up (autoscale)
- ⚠️ PostgreSQL database needs to be created manually

### Next Steps Required
To fully enable all features, you need to:
1. Create a PostgreSQL database:
   - Open "All tools" menu (four squares icon) in the left sidebar
   - Select the PostgreSQL database icon
   - Click "Create a database"
   - Replit will automatically set the DATABASE_URL environment variable

2. After database creation, run migrations:
   ```bash
   npm run db:push
   ```

## Recent Changes (November 16, 2025)
- Imported GitHub project and organized file structure
- Configured Vite server for Replit environment (0.0.0.0:5000 with HMR clientPort 443)
- Updated .gitignore with comprehensive Node.js patterns
- Set up dev-server workflow
- Configured deployment settings (autoscale with build and run commands)
- Requested and configured OPENROUTER_API_KEY secret
- Updated AI model to Meta Llama 3.3 70B Instruct
- Added Firebase Email/Password Authentication with login page

## Project Architecture

### Technology Stack
- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Express.js + Node.js
- **Database**: PostgreSQL with Drizzle ORM
- **Authentication**: Firebase Email/Password Authentication
- **AI Service**: OpenRouter API (using Meta Llama 3.3 70B Instruct model)
- **UI Components**: Radix UI + Tailwind CSS + Framer Motion

### Project Structure
```
├── client/               # Frontend React application
│   ├── src/
│   │   ├── components/  # UI components
│   │   ├── pages/       # Page components (home, predict, history)
│   │   ├── hooks/       # Custom React hooks
│   │   └── lib/         # Utilities and query client
│   └── index.html
├── server/              # Backend Express server
│   ├── index.ts         # Main server entry point
│   ├── routes.ts        # API route handlers
│   ├── storage.ts       # Database operations
│   └── vite.ts          # Vite dev server integration
├── shared/              # Shared types and schemas
│   └── schema.ts        # Database schema and validation
└── attached_assets/     # Static assets (crop images)
```

### Key Features
1. **User Authentication**: Firebase email/password login with location field
2. **Prediction Form**: Input soil and environmental parameters
3. **AI Recommendations**: Get crop suggestions with confidence scores
4. **Prediction History**: View and manage past predictions (requires database)
5. **Responsive UI**: Works on desktop and mobile devices
6. **Dark/Light Theme**: User preference toggle

### API Endpoints
- `POST /api/predict` - Generate crop recommendation
- `GET /api/predictions` - Retrieve prediction history
- `DELETE /api/predictions/:id` - Delete a prediction

### Database Schema
The `predictions` table stores:
- Soil parameters (nitrogen, phosphorus, potassium, pH)
- Environmental data (temperature, humidity, rainfall)
- AI predictions (recommended crop, confidence, alternatives)
- Timestamp (createdAt)

### Available Crop Types
rice, wheat, maize, chickpea, kidneybeans, pigeonpeas, mothbeans, mungbean, blackgram, lentil, pomegranate, banana, mango, grapes, watermelon, muskmelon, apple, orange, papaya, coconut, cotton, jute, coffee

## Environment Variables
- `OPENROUTER_API_KEY` - API key for OpenRouter AI service (configured)
- `DATABASE_URL` - PostgreSQL connection string (needs database creation)
- `PORT` - Server port (defaults to 5000)
- `NODE_ENV` - Environment mode (development/production)
- `VITE_FIREBASE_API_KEY` - Firebase API key for authentication
- `VITE_FIREBASE_AUTH_DOMAIN` - Firebase auth domain
- `VITE_FIREBASE_PROJECT_ID` - Firebase project ID
- `VITE_FIREBASE_STORAGE_BUCKET` - Firebase storage bucket
- `VITE_FIREBASE_MESSAGING_SENDER_ID` - Firebase messaging sender ID
- `VITE_FIREBASE_APP_ID` - Firebase app ID

## Development Commands
- `npm run dev` - Start development server with Vite HMR
- `npm run build` - Build for production
- `npm start` - Start production server
- `npm run check` - Run TypeScript type checking
- `npm run db:push` - Push database schema changes

## User Preferences
No specific user preferences recorded yet.

## Notes
- The application uses port 5000 exclusively (both frontend and backend)
- Vite is configured to allow all hosts for Replit's proxy environment
- The server uses SO_REUSEPORT for better performance
- AI model responses are parsed from JSON format with fallback error handling
