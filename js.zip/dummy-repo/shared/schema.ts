import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const predictions = pgTable("predictions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  nitrogen: real("nitrogen").notNull(),
  phosphorus: real("phosphorus").notNull(),
  potassium: real("potassium").notNull(),
  temperature: real("temperature").notNull(),
  humidity: real("humidity").notNull(),
  ph: real("ph").notNull(),
  rainfall: real("rainfall").notNull(),
  recommendedCrop: text("recommended_crop").notNull(),
  confidence: real("confidence").notNull(),
  alternativeCrops: text("alternative_crops").array(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertPredictionSchema = createInsertSchema(predictions, {
  nitrogen: z.number().min(0).max(140),
  phosphorus: z.number().min(0).max(140),
  potassium: z.number().min(0).max(140),
  temperature: z.number().min(0).max(50),
  humidity: z.number().min(0).max(100),
  ph: z.number().min(3).max(10),
  rainfall: z.number().min(0).max(300),
}).omit({
  id: true,
  createdAt: true,
});

export type InsertPrediction = z.infer<typeof insertPredictionSchema>;
export type Prediction = typeof predictions.$inferSelect;

// Crop input parameters
export const cropInputSchema = z.object({
  nitrogen: z.number().min(0).max(140),
  phosphorus: z.number().min(0).max(140),
  potassium: z.number().min(0).max(140),
  temperature: z.number().min(0).max(50),
  humidity: z.number().min(0).max(100),
  ph: z.number().min(3).max(10),
  rainfall: z.number().min(0).max(300),
});

export type CropInput = z.infer<typeof cropInputSchema>;
