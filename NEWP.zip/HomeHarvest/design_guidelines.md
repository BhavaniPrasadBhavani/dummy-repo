# CropAI Advisor - Design Guidelines

## Design Approach
**Selected System:** Material Design principles adapted for agricultural utility
**Justification:** Function-focused application requiring clear data input, reliable predictions, and mobile-first accessibility for farmers. Prioritizes usability, readability in outdoor conditions, and trust-building through professional presentation.

## Core Design Elements

### A. Color Palette

**Light Mode:**
- Primary: 115 45% 35% (Deep forest green - trust, growth, agriculture)
- Primary Light: 115 45% 85% (Soft green backgrounds)
- Secondary: 35 65% 50% (Warm earth brown - soil, grounding)
- Accent: 25 85% 55% (Vibrant orange - calls-to-action, energy)
- Success: 145 60% 45% (Confirmation green)
- Warning: 45 90% 55% (Alert yellow)
- Error: 0 70% 50% (Validation red)
- Background: 0 0% 98% (Soft white)
- Surface: 0 0% 100% (Pure white cards)
- Text Primary: 0 0% 15% (Near black)
- Text Secondary: 0 0% 45% (Medium gray)

**Dark Mode:**
- Primary: 115 35% 65% (Lighter green for contrast)
- Primary Dark: 115 30% 20% (Dark green backgrounds)
- Secondary: 35 45% 60% (Lighter earth tone)
- Accent: 25 75% 60% (Adjusted orange)
- Background: 0 0% 8% (Deep dark)
- Surface: 0 0% 12% (Card surfaces)
- Text Primary: 0 0% 95% (Near white)
- Text Secondary: 0 0% 65% (Light gray)

### B. Typography

**Font Families:**
- Primary: 'Inter' (Google Fonts) - clean, modern, excellent readability
- Data/Numbers: 'JetBrains Mono' - monospaced for parameter values

**Type Scale:**
- Hero/Display: text-5xl font-bold (48px)
- Page Titles: text-3xl font-semibold (30px)
- Section Headers: text-2xl font-semibold (24px)
- Card Titles: text-xl font-semibold (20px)
- Body Large: text-lg font-normal (18px)
- Body: text-base font-normal (16px)
- Small: text-sm font-normal (14px)
- Caption: text-xs font-medium (12px)

**Special Treatments:**
- Parameter labels: text-sm font-semibold uppercase tracking-wide
- Crop names: text-2xl font-bold
- Confidence scores: text-4xl font-bold font-mono
- Input values: font-mono for precision

### C. Layout System

**Tailwind Spacing Primitives:** 4, 6, 8, 12, 16, 24 units
- Micro spacing (icons, badges): p-2, gap-2
- Component padding: p-4, p-6
- Section spacing: py-12, py-16
- Large gaps: gap-8, gap-12
- Page margins: px-4 (mobile), px-6 (tablet), px-8 (desktop)

**Container Widths:**
- Mobile: Full width with px-4
- Tablet: max-w-2xl mx-auto
- Desktop: max-w-4xl mx-auto (app-like focused experience)

**Grid System:**
- Parameter inputs: grid-cols-1 md:grid-cols-2 gap-4
- History cards: grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6
- Results alternatives: grid-cols-2 gap-4

### D. Component Library

**Navigation:**
- Bottom tab bar (mobile-first): Fixed bottom, 4 icons with labels
- Tabs: Home, Predict, Results, History
- Active state: Primary color fill with icon color change
- Smooth transitions between screens

**Input Forms:**
- Floating label inputs with helper text below
- Slider controls for better mobile UX (N, P, K ranges)
- Number inputs with +/- steppers for precision
- Real-time validation with inline error states
- Range indicators showing min/max acceptable values
- Unit labels (°C, %, mm) clearly visible
- Input groups with subtle borders and rounded corners (rounded-lg)

**Cards:**
- Elevated cards: shadow-md rounded-xl p-6
- History cards: White/dark surface with border-l-4 (accent color)
- Result cards: Prominent shadow-lg with gradient background overlay
- Parameter summary cards: Compact, chip-like display

**Buttons:**
- Primary CTA: Large rounded-full px-8 py-4 with accent color
- Secondary: Outline variant with primary color
- Icon buttons: Circular, minimal padding
- Loading states: Spinner with text "Analyzing soil parameters..."

**Data Display:**
- Confidence meters: Circular progress indicators
- Parameter chips: Rounded-full with icon + value + unit
- Crop cards: Image thumbnail + name + optimal conditions
- Chart displays: Bar charts for parameter ranges (using react-chartjs-2)

**Feedback Elements:**
- Success: Green toast notifications, slide-in from top
- Warnings: Yellow banner with icon
- Errors: Red inline messages below inputs
- Loading: Full-screen overlay with spinning crop icon animation
- Empty states: Illustration + message + CTA for history

### E. Screen-Specific Designs

**Home Screen:**
- Large hero section with agricultural illustration (tractor/field)
- App logo with tagline "AI-Powered Crop Intelligence"
- Two prominent CTAs: "Get Recommendation" and "View History"
- Feature cards showing: Accuracy (99.55%), Crops Supported (22), Offline Ready
- Quick stats counter animation on load

**Prediction Input Screen:**
- Step indicator (1 of 1 - all on one page)
- Grouped parameter sections with icons:
  - Soil Nutrients (N, P, K) - beaker icon
  - Climate (Temperature, Humidity) - sun/cloud icon  
  - Soil Properties (pH, Rainfall) - droplet icon
- Each parameter has slider + number input combo
- Location button: "Use my weather data" (if available)
- Large predict button at bottom, sticky on scroll

**Results Screen:**
- Celebration animation on load (confetti for high confidence)
- Primary crop display: Large card with crop image, name, confidence circle
- "Why this crop?" expandable section with optimal conditions
- Alternative crops: Horizontal scrollable cards
- Action buttons: "Save to History", "Start New Prediction", "Share Results"
- Environmental match indicators: Visual bars showing parameter fit

**History Screen:**
- Search bar at top with filter chips (date range, crop type)
- Timeline view with date separators
- Swipe-to-delete gesture on cards
- Each card shows: Date, thumbnail of all parameters, recommended crop, confidence badge
- Empty state: Farmer illustration with "No predictions yet"

## Images & Illustrations

**Hero Images:**
- Home screen hero: Wide agricultural landscape (green fields, blue sky) - 1200x600px
- Crop result images: High-quality photos of each of 22 crops - 400x300px
- Empty state illustrations: Friendly, minimal line art style in brand colors

**Icon Treatment:**
- Use Heroicons for UI elements
- Custom crop icons: Simple, recognizable silhouettes in SVG
- Parameter icons: Material Design icons via CDN

**Image Placement:**
- Home hero: Full-width, subtle overlay gradient (bottom to top) for text legibility
- Crop thumbnails: Rounded-lg with subtle shadow in result cards
- History cards: Small circular crop thumbnail (64x64px)

## Animations

**Minimal, Purposeful Animations:**
- Screen transitions: Slide-in from right (150ms ease-out)
- Button press: Scale down to 0.95 with haptic feedback feel
- Loading prediction: Pulsing progress bar with percentage
- Success states: Gentle bounce on result cards
- Parameter sliders: Smooth value transitions

**No Animations:**
- Background effects
- Parallax scrolling
- Continuous looping animations

## Accessibility & Mobile Optimization

- Minimum touch target: 44x44px for all interactive elements
- High contrast mode support with AAA compliance
- Offline indicator: Persistent banner when no connection
- Form validation: Immediate, clear feedback
- Dark mode: Full implementation across all screens
- Landscape orientation: Optimized layouts for both orientations
- Large text support: Scales gracefully up to 200%

## Trust & Credibility Elements

- Model accuracy badge prominently displayed: "99.55% Accurate"
- Confidence percentages shown clearly with visual indicators
- "Powered by Machine Learning" subtle badge
- Data privacy note: "All predictions processed locally"
- Last updated timestamp on predictions

This design creates a professional, trustworthy agricultural tool that farmers can rely on for critical crop decisions while maintaining excellent usability in field conditions.