import { FileQuestion } from "lucide-react";
import { Button } from "@/components/ui/button";

interface EmptyHistoryProps {
  onGetStarted: () => void;
}

export function EmptyHistory({ onGetStarted }: EmptyHistoryProps) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="mb-6 p-6 rounded-full bg-muted">
        <FileQuestion className="h-16 w-16 text-muted-foreground" />
      </div>
      <h3 className="text-2xl font-semibold mb-2">No Predictions Yet</h3>
      <p className="text-muted-foreground mb-6 max-w-md">
        Start by getting your first crop recommendation based on your soil and environmental parameters.
      </p>
      <Button onClick={onGetStarted} data-testid="button-get-started">
        Get Your First Prediction
      </Button>
    </div>
  );
}
