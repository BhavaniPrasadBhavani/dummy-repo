import { BottomNav } from "../BottomNav";
import { Router } from "wouter";

export default function BottomNavExample() {
  return (
    <Router>
      <div className="h-20">
        <BottomNav />
      </div>
    </Router>
  );
}
