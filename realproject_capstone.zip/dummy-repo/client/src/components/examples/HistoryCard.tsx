import { HistoryCard } from "../HistoryCard";

export default function HistoryCardExample() {
  const mockPrediction = {
    id: "1",
    nitrogen: 90,
    phosphorus: 42,
    potassium: 43,
    temperature: 20.87,
    humidity: 82,
    ph: 6.5,
    rainfall: 203,
    recommendedCrop: "rice",
    confidence: 0.90,
    alternativeCrops: ["jute", "pomegranate"],
    createdAt: new Date(),
  };

  return (
    <div className="max-w-md mx-auto p-4">
      <HistoryCard
        prediction={mockPrediction}
        onDelete={(id) => console.log("Delete clicked:", id)}
      />
    </div>
  );
}
