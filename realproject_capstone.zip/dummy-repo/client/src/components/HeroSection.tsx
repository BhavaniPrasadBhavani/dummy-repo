import { Sprout } from "lucide-react";
import { Button } from "@/components/ui/button";
import heroImage from "@assets/stock_images/agricultural_green_f_ca33b1a0.jpg";

interface HeroSectionProps {
  onGetStarted: () => void;
  onViewHistory: () => void;
}

export function HeroSection({ onGetStarted, onViewHistory }: HeroSectionProps) {
  return (
    <div className="relative w-full h-[500px] flex items-center justify-center overflow-hidden">
      <img
        src={heroImage}
        alt="Agricultural field"
        className="absolute inset-0 w-full h-full object-cover"
      />
      <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/40 to-black/20" />
      
      <div className="relative z-10 text-center px-4 max-w-3xl mx-auto">
        <div className="flex items-center justify-center gap-3 mb-4">
          <Sprout className="h-12 w-12 text-white" />
          <h1 className="text-5xl font-bold text-white">CropAI Advisor</h1>
        </div>
        
        <p className="text-xl text-white/90 mb-8">
          AI-Powered Crop Intelligence for Better Farming Decisions
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button
            size="lg"
            onClick={onGetStarted}
            data-testid="button-get-started"
            className="bg-primary text-primary-foreground border border-primary-border hover-elevate active-elevate-2"
          >
            Get Recommendation
          </Button>
          <Button
            size="lg"
            variant="outline"
            onClick={onViewHistory}
            data-testid="button-view-history"
            className="bg-background/20 backdrop-blur-sm text-white border-white/30 hover:bg-background/30"
          >
            View History
          </Button>
        </div>
      </div>
    </div>
  );
}
