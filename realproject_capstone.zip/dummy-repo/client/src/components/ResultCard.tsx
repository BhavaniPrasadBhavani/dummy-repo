import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { CheckCircle2, ArrowRight } from "lucide-react";
import riceImage from "@assets/stock_images/rice_paddy_field_cro_5f988ac2.jpg";
import wheatImage from "@assets/stock_images/wheat_field_golden_c_2a8ab677.jpg";
import cornImage from "@assets/stock_images/corn_maize_crop_fiel_e84fe321.jpg";

interface ResultCardProps {
  crop: string;
  confidence: number;
  alternatives?: Array<{ crop: string; confidence: number }>;
  onNewPrediction?: () => void;
}

const cropImages: Record<string, string> = {
  rice: riceImage,
  wheat: wheatImage,
  corn: cornImage,
  maize: cornImage,
};

export function ResultCard({ crop, confidence, alternatives = [], onNewPrediction }: ResultCardProps) {
  const cropImage = cropImages[crop.toLowerCase()] || riceImage;

  return (
    <div className="space-y-6">
      <Card className="shadow-lg">
        <CardHeader>
          <div className="flex items-center gap-2 text-green-600">
            <CheckCircle2 className="h-6 w-6" />
            <CardTitle>Recommended Crop</CardTitle>
          </div>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="relative h-48 rounded-lg overflow-hidden">
            <img
              src={cropImage}
              alt={crop}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-4 left-4">
              <h2 className="text-3xl font-bold text-white capitalize mb-1">{crop}</h2>
              <Badge variant="secondary" className="bg-white/20 text-white backdrop-blur-sm">
                Primary Recommendation
              </Badge>
            </div>
          </div>

          <div className="flex items-center justify-center">
            <div className="text-center">
              <div className="text-6xl font-bold font-mono text-primary mb-2" data-testid="text-confidence">
                {(confidence * 100).toFixed(1)}%
              </div>
              <p className="text-sm text-muted-foreground">Confidence Score</p>
            </div>
          </div>

          <div className="flex gap-3">
            {onNewPrediction && (
              <Button
                className="flex-1"
                onClick={onNewPrediction}
                data-testid="button-new-prediction"
              >
                New Prediction
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      {alternatives.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Alternative Recommendations</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {alternatives.map((alt, index) => (
                <div
                  key={index}
                  className="flex items-center justify-between p-3 rounded-lg bg-muted/50 hover-elevate"
                  data-testid={`alternative-${index}`}
                >
                  <span className="font-medium capitalize">{alt.crop}</span>
                  <span className="font-mono text-sm text-muted-foreground">
                    {(alt.confidence * 100).toFixed(1)}%
                  </span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
