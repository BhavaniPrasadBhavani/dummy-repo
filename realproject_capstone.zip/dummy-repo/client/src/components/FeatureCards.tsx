import { Brain, Leaf, Wifi } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";

const features = [
  {
    icon: Brain,
    title: "99.55% Accurate",
    description: "Advanced ML model trained on thousands of crop datasets",
  },
  {
    icon: Leaf,
    title: "22 Crop Types",
    description: "Comprehensive recommendations for diverse agricultural needs",
  },
  {
    icon: Wifi,
    title: "Offline Ready",
    description: "All predictions processed locally on your device",
  },
];

export function FeatureCards() {
  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 max-w-5xl mx-auto px-4 py-12">
      {features.map((feature, index) => (
        <Card key={index} className="hover-elevate" data-testid={`card-feature-${index}`}>
          <CardContent className="p-6 text-center">
            <div className="flex justify-center mb-4">
              <div className="p-3 rounded-lg bg-primary/10">
                <feature.icon className="h-8 w-8 text-primary" />
              </div>
            </div>
            <h3 className="text-xl font-semibold mb-2">{feature.title}</h3>
            <p className="text-muted-foreground">{feature.description}</p>
          </CardContent>
        </Card>
      ))}
    </div>
  );
}
