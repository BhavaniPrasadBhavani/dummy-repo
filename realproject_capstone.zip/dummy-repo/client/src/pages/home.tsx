import { useLocation } from "wouter";
import { HeroSection } from "@/components/HeroSection";
import { FeatureCards } from "@/components/FeatureCards";

export default function Home() {
  const [, setLocation] = useLocation();

  return (
    <div className="min-h-screen">
      <HeroSection
        onGetStarted={() => setLocation("/predict")}
        onViewHistory={() => setLocation("/history")}
      />
      <FeatureCards />
    </div>
  );
}
