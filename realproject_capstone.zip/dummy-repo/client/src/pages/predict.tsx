import { useState } from "react";
import { useLocation } from "wouter";
import { PredictionForm } from "@/components/PredictionForm";
import { ResultCard } from "@/components/ResultCard";
import { useToast } from "@/hooks/use-toast";
import type { CropInput } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

interface PredictionResult {
  recommendedCrop: string;
  confidence: number;
  alternatives: Array<{ crop: string; confidence: number }>;
  reasoning?: string;
}

export default function Predict() {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const [result, setResult] = useState<PredictionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (data: CropInput) => {
    setIsLoading(true);
    
    try {
      const response = await apiRequest("POST", "/api/predict", data);
      const prediction = await response.json();
      setResult({
        recommendedCrop: prediction.recommendedCrop,
        confidence: prediction.confidence,
        alternatives: prediction.alternatives || [],
        reasoning: prediction.reasoning,
      });

      toast({
        title: "Prediction Complete",
        description: `Recommended crop: ${prediction.recommendedCrop}`,
      });
    } catch (error) {
      console.error("Prediction error:", error);
      toast({
        title: "Prediction Failed",
        description: error instanceof Error ? error.message : "Failed to get crop recommendation",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const handleNewPrediction = () => {
    setResult(null);
  };

  return (
    <div className="min-h-screen py-8 px-4">
      <div className="max-w-2xl mx-auto">
        <div className="mb-8">
          <h1 className="text-3xl font-bold mb-2">Get Crop Recommendation</h1>
          <p className="text-muted-foreground">
            Enter your soil and environmental parameters for AI-powered crop suggestions
          </p>
        </div>

        {!result ? (
          <PredictionForm onSubmit={handleSubmit} isLoading={isLoading} />
        ) : (
          <ResultCard
            crop={result.recommendedCrop}
            confidence={result.confidence}
            alternatives={result.alternatives}
            onNewPrediction={handleNewPrediction}
          />
        )}
      </div>
    </div>
  );
}
